<?php
    require_once("CadastroProfissional.class.php");

    $cpf = $_POST["cpf"];
    $formacao = $_POST["formacao"];
    $horario = $_POST["horario"];
    $forma = $_POST["forma"];

    $objetoProfissional = new Profissional($cpf, $formacao, $horario, $forma);
    $objetoProfissional->dadosProfissional();
    $objetoProfissional->inserirProfissional();