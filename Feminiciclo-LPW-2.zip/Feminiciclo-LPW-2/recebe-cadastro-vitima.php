<?php
    require_once("CadastroVitima.class.php");

    $nome = $_POST["nome"];
    $sobrenome = $_POST["sobrenome"];
    $idade = $_POST["idade"];
    $rg = $_POST["rg"];
    $boletim = $_POST["boletim"];

    $objetoVitima = new Vitima($nome, $sobrenome, $idade, $rg, $boletim);
    $objetoVitima->dadosVitima();
    $objetoVitima->inserirVitima();