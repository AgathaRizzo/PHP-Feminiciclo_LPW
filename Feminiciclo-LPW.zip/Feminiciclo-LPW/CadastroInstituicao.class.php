<?php
 class Instituicao {
     private $nomeInstituicao;
     private $enderecoInstituicao;
     private $tipo;

    public function dadosInstituicao(){
        echo "<br />";
        echo "O nome da ". __CLASS__ ." é: ". $this->nomeInstituicao;
        echo "<br />";
        echo "O endereço da ". __CLASS__ ." é: ". $this->enderecoInstituicao;
        echo "<br />";
        echo "O tipo de apoio da ".__CLASS__." é: ". $this->tipo;
    } 
    public function __construct($nomeInstituicao, $enderecoInstituicao, $tipo){
        $this->nomeInstituicao = $nomeInstituicao;
        $this->enderecoInstituicao = $enderecoInstituicao;
        $this->tipo = $tipo;
        echo "<br />Dados enviados";
    }
    public function setNomeInstituicao($nomeInstituicao){
        $this->nomeInstituicao = $nomeInstituicao;
    }
    
    public function getNomeInstituicao(){
        return $this->nomeInstituicao;
    }
    public function setEnderecoInstituicao($enderecoInstituicao){
        $this->enderecoInstituicao = $enderecoInstituicao;
    }
    public function getEnderecoInstituicao(){
        return $this->enderecoInstituicao;
    }
    public function setTipo($tipo){
        $this->tipo = $tipo;
    }
    public function gettipo(){
        return $this->tipo;
    }

    public function inserirInstituicao()
        {
            //Conectar com o BD
            $conexao = mysqli_connect("localhost","root","", "escola");
            
            //Verificando a conexão
            if(!$conexao){
                die("Falha na conexão com o BD");
            }
            echo "Conectado com o banco";

            //Criando a string de inserção (código SQL)
            $sql = "INSERT INTO instituicao VALUES ('$this->nomeInstituicao', '$this->enderecoInstituicao', '$this->tipo')";
           
            //Executando a inserção e verificando sucesso
            if(mysqli_query($conexao, $sql)){
                echo "Instituicao adicionada com sucesso";
            }else{
                echo "Erro: ".mysqli_error($conexao);
            }
            mysqli_close($conexao);
        }
 }