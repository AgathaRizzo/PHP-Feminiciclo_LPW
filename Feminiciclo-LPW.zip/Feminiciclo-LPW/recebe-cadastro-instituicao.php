<?php
    require_once("CadastroInstituicao.class.php");

    $nomeInstituicao = $_POST["nomeInstituicao"];
    $enderecoInstituicao = $_POST["enderecoInstituicao"];
    $tipo = $_POST["tipo"];

    $objetoInstituicao = new Instituicao($nomeInstituicao, $enderecoInstituicao, $tipo);
    $objetoInstituicao->dadosInstituicao();
    $objetoInstituicao->inserirInstituicao();